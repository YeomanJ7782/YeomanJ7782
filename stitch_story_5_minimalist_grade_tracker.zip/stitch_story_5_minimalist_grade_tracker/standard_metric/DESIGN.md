# Design System Document: The Academic Ledger

## 1. Overview & Creative North Star
### Creative North Star: The Monochromatic Editorial
This design system rejects the "standard dashboard" aesthetic in favor of high-end editorial precision. Inspired by architectural blueprints and premium print journals, it prioritizes legibility, intentional asymmetry, and the "luxury of space." By stripping away color, we force the user to focus on the raw data—grades, progress, and performance—elevating a simple tracking app into a sophisticated academic record.

The system breaks the template look through **intentional white space** and **extreme typographic scaling**. We do not fill the screen; we curate it.

---

## 2. Colors: The Gray Scale
The palette is restricted to a sophisticated range of blacks, whites, and meticulously balanced grays.

*   **Primary (`#000000`):** Reserved for the most critical actions and the highest level of typographic hierarchy.
*   **Surface Hierarchy & Nesting:** Instead of a flat grid, we treat the UI as stacked sheets of fine paper.
    *   **Background (`#f9f9f9`):** The base canvas.
    *   **Surface-Container-Low (`#f3f3f3`):** Use for large structural sections (e.g., a sidebar or a secondary content area).
    *   **Surface-Container-Lowest (`#ffffff`):** Use for high-priority cards or interactive elements sitting atop the background.
*   **The "No-Line" Rule:** Standard 1px solid borders for sectioning are strictly prohibited. Boundaries must be defined solely through background color shifts or the **Tonal Transition**—placing a `surface-container-lowest` element on a `surface-container-low` background.
*   **The Glass & Gradient Rule:** To ensure the system feels bespoke rather than generic, use **Glassmorphism** for floating overlays (e.g., Modals or Navigation bars) using semi-transparent surface colors with a `20px` backdrop-blur. For main CTAs, use a subtle linear gradient from `primary` (#000000) to `primary_container` (#3b3b3b) to provide a "metallic" depth.

---

## 3. Typography: Authority Through Inter
We utilize **Inter** to create a technical, yet approachable feel. The hierarchy is the "spine" of this design system.

*   **Display & Headline (The Bold Statement):** Use `display-lg` and `headline-lg` for grade averages and GPA. These should be `font-weight: 800` (ExtraBold) to create high-contrast focal points against the whitespace.
*   **Title (The Narrative):** `title-lg` and `title-md` are used for course names and semester headers. They provide the anchor for each content block.
*   **Body (The Detail):** `body-md` is the workhorse for descriptions and feedback. 
*   **Label (The Metadata):** `label-md` and `label-sm` should be used for dates, credit counts, and secondary data. Use `letter-spacing: 0.05em` to give these a refined, technical feel.

---

## 4. Elevation & Depth
Hierarchy is achieved through **Tonal Layering** rather than traditional structural lines or heavy shadows.

*   **The Layering Principle:** Depth is "stacked." Place a `surface-container-lowest` card on a `surface-container-low` section to create a soft, natural lift. This mimics the physical stacking of paper.
*   **Ambient Shadows:** For floating elements (like a "Add Grade" FAB), shadows must be extra-diffused. Use a blur of `32px` at `4%` opacity using `on_surface` (#1b1b1b). It should feel like an ambient glow, not a drop shadow.
*   **The "Ghost Border" Fallback:** If a container needs containment against a white background, use a "Ghost Border": the `outline_variant` (#c6c6c6) at **15% opacity**. Never use a 100% opaque border.
*   **Glassmorphism:** Apply to top navigation bars. Use `surface` at 80% opacity with a heavy backdrop-blur. This allows the high-contrast typography to "float" over the content as the user scrolls.

---

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (#000000) with `on_primary` (#e2e2e2) text. Use `rounded-md` (0.375rem).
*   **Secondary:** `surface_container_highest` (#e2e2e2) background with `on_surface` text.
*   **Tertiary:** No background. Bold `primary` text with a 2px underline that appears only on hover.

### Input Fields
*   **Styling:** Forbid 4-sided boxes. Use a `surface_container_high` (#e8e8e8) background with a bottom-only `outline` (#777777) at 2px.
*   **Focus State:** The bottom border transforms to `primary` (#000000) and the background lightens to `surface_container_lowest` (#ffffff).

### Grade Cards
*   **Rule:** Forbid the use of divider lines between assignments.
*   **Layout:** Use `surface_container_low` (#f3f3f3) as the card base. Use `headline-sm` for the grade (e.g., "A") and `label-md` for the assignment weight. Separate assignments using a `24px` vertical spacing scale rather than lines.

### The "Grade Pulse" (Custom Component)
*   A specialized chip for grade trends. A `primary` background chip with `label-sm` text (e.g., "+2.3%"). It should be placed asymmetrically in the top-right corner of a card to break the grid.

### Checkboxes & Radios
*   Use `rounded-none` for a sharp, architectural look. When checked, the fill is `primary` with a white checkmark.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace the Void:** Use 2x the standard padding you would normally use. Whitespace is a luxury item.
*   **Weight as Color:** Use font weight (ExtraBold vs Regular) to differentiate data types since you cannot use color.
*   **Asymmetric Alignment:** Align headers to the far left and data to the far right to create a wide "editorial" horizontal axis.

### Don't:
*   **No Dividers:** Never use a horizontal rule `<hr>` to separate content. Use a `16px` or `24px` gap or a subtle shift in the gray background.
*   **No Pure Grays for Text:** Always use `on_surface` (#1b1b1b) for readability. Do not wash out the text to light gray; it kills the "high contrast" requirement.
*   **Avoid "Bubbly" UI:** Keep the `roundedness` scale strictly to `sm` or `md` for containers. Only use `full` (9999px) for pill-style labels or functional chips.