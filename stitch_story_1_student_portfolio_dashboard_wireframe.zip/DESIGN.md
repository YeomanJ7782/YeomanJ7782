# Design System Documentation: The Architectural Blueprint

## 1. Overview & Creative North Star
**Creative North Star: "The Architectural Blueprint"**

This design system is not a mere "wireframe"—it is a high-end editorial exercise in structural purity. By stripping away the crutches of color and ornamentation, we elevate the interface to a level of "Architectural Brutalism." We treat the screen as a technical drawing of a masterpiece. 

To move beyond the "standard wireframe" look, this system relies on **intentional asymmetry**, **dramatic typographic scale**, and **tonal depth**. We break the monotony of the grid by allowing elements to breathe through expansive white space, creating a "Digital Curator" experience where every pixel feels calculated and every box feels like a deliberate architectural choice.

## 2. Colors
The palette is strictly monochromatic, utilizing the depth of the grayscale spectrum to indicate hierarchy and function.

*   **Primary (#000000):** Reserved for high-impact structural elements and dominant actions.
*   **Surface Hierarchy:** Instead of flat gray boxes, use the `surface-container` tiers to create a "nested" logic. 
    *   **Surface Lowest (#ffffff):** Used for elevated interactive cards.
    *   **Surface (#f9f9f9):** The standard canvas.
    *   **Surface Container High (#e8e8e8):** Used for recessed utility areas or navigation sidebars.
*   **The "No-Line" Rule for Sectioning:** Do not use 1px solid borders to separate major sections. Boundaries must be defined by shifts in background tokens (e.g., a `surface-container-low` section meeting a `surface` background).
*   **Signature Textures:** For high-end CTAs, employ a subtle linear gradient from `primary` (#000000) to `primary-container` (#3b3b3b). This creates a "satin black" finish that feels premium rather than flat.
*   **Glassmorphism:** For floating elements (menus, modals), use a semi-transparent `surface` color with a `backdrop-filter: blur(20px)`. This integrates the UI layers into a cohesive, atmospheric whole.

## 3. Typography
We utilize **Inter** as a singular, authoritative typeface. The soul of this system lies in the contrast between the massive and the minuscule.

*   **Display (L/M/S):** Used for editorial "hero" moments. These should be tight-tracked and bold, often placed asymmetrically to anchor the page.
*   **Headline & Title:** These define the technical structure. Use `headline-lg` (2rem) for section headers to provide an authoritative "blueprint" feel.
*   **Body & Labels:** `body-md` (0.875rem) provides the core readability, while `label-sm` (0.6875rem) in all-caps should be used for technical metadata, mimicking the annotations on an architect's plan.
*   **Hierarchy Note:** Always pair a `display-lg` headline with a `label-md` sub-header. This extreme variance in scale is what transforms a "wireframe" into a "design."

## 4. Elevation & Depth
In a world of 0px rounded corners, depth must be sophisticated. We reject "standard" drop shadows.

*   **The Layering Principle:** Stacking is the primary method of hierarchy. A `surface-container-lowest` (#ffffff) card placed on a `surface-container-low` (#f3f3f4) background creates a "natural lift" through tonal contrast alone.
*   **Ambient Shadows:** When a "floating" effect is mandatory, use an extra-diffused shadow: `box-shadow: 0 20px 40px rgba(26, 28, 28, 0.06)`. This mimics soft, natural gallery lighting.
*   **The "Ghost Border" Fallback:** For input fields or containment where a line is required, use a "Ghost Border"—the `outline-variant` token at 15% opacity. This provides a structural hint without cluttering the visual field with harsh lines.
*   **Sharp Geometry:** All containers, buttons, and inputs must strictly adhere to **0px border-radius**. The beauty is in the precision of the right angle.

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (#000000) with `on-primary` (#e2e2e2) text. 0px radius. Use generous horizontal padding (24px+) to emphasize the horizontal plane.
*   **Secondary:** A `ghost-border` outline with `primary` text.
*   **Tertiary:** Minimalist `label-md` text with a 2px `primary` underline that expands on hover.

### Input Fields
*   **State:** Underline-only or full-box with a `ghost-border`. 
*   **Labels:** Always use `label-sm` in all-caps, positioned 8px above the input field to maintain a technical "blueprint" aesthetic.
*   **Error State:** Use `error` (#ba1a1a) only for the stroke and helper text. Do not fill the box with color.

### Cards & Lists
*   **Rule:** Forbid the use of divider lines. 
*   **Alternative:** Use `surface-container` shifts or 32px/48px of vertical white space to distinguish items. In lists, use a `surface-variant` hover state to provide interactive feedback without adding permanent lines.

### Technical Metadata (New Component)
*   Small, mono-spaced-style `label-sm` text placed in the corners of sections to denote "Version," "Section ID," or "Scale." This reinforces the "Architectural Blueprint" theme.

## 6. Do's and Don'ts

### Do
*   **Do** embrace negative space. If a layout feels crowded, double the white space between sections.
*   **Do** use asymmetrical layouts. Align text to the left while keeping some images or CTA boxes right-heavy.
*   **Do** use tonal shifts (`surface` vs `surface-container`) as your primary tool for grouping information.

### Don't
*   **Don't** use rounded corners. Ever. (0px is the absolute rule).
*   **Don't** use 1px black borders to wrap every content block. This makes the UI look like a basic table rather than an editorial experience.
*   **Don't** use "Drop Shadow" presets. If an element needs to float, it must do so with ambient, nearly invisible blurs.
*   **Don't** use iconography as a decoration. Icons must be structural and sparse, using the same weight as the typography.