# Design System Documentation: The Structural Blueprint

## 1. Overview & Creative North Star
The "Structural Blueprint" is a high-end, editorial approach to low-fidelity wireframing. It moves away from the "unfinished" look of typical wireframes and instead adopts a philosophy of **Architectural Brutalism**. By stripping away ornamentation and relying strictly on a 0px radius scale, we celebrate the raw honesty of the layout. 

The Creative North Star for this design system is **"The Unadorned Foundation."** It treats digital space like a physical gallery—where the absence of color and the precision of the grid create an environment of extreme clarity and authoritative intent. We break the "template" look through intentional asymmetry and a rigid adherence to tonal depth rather than structural lines.

## 2. Colors & Surface Philosophy
This design system utilizes a monochromatic Material Design palette to define importance through value rather than hue.

### The "No-Line" Rule
Standard wireframes rely on 1px borders to define boxes. **This design system prohibits 1px solid borders for sectioning.** Boundaries must be defined solely through background color shifts. For example, a `surface-container-low` (#f3f3f3) section should sit against a `surface` (#f9f9f9) background to create a visible but soft boundary.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked sheets of high-grade paper. Use the surface-container tiers to create "nested" depth:
*   **Base Layer:** `surface` (#f9f9f9)
*   **Primary Content Area:** `surface-container-lowest` (#ffffff) to provide maximum "pop" for content.
*   **Secondary/Sidebar Areas:** `surface-container` (#eeeeee) or `surface-dim` (#dadada).
*   **High-Impact Overlays:** `surface-container-highest` (#e2e2e2).

### The "Glass & Gradient" Rule
To elevate the wireframe beyond a "basic box" feel, utilize semi-transparent surface colors. When an element floats over content, use `surface_container_lowest` with a 85% opacity and a 20px backdrop blur. For main CTAs, a subtle linear gradient from `primary` (#000000) to `primary_container` (#3b3b3b) provides a "lithographic" depth that feels premium and tactile.

## 3. Typography
The system uses **Inter** exclusively, focusing on a high-contrast scale to drive the editorial narrative.

*   **Display Scale:** Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create "hero" moments. This isn't just text; it's a structural anchor.
*   **Headline Scale:** `headline-lg` (2rem) serves as the primary separator for major content blocks.
*   **Body Scale:** `body-lg` (1rem) should be used with generous line-height (1.6) to ensure the minimalist layout feels breathable and sophisticated.
*   **Label Scale:** `label-sm` (0.6875rem) should always be in ALL CAPS with +0.05em letter-spacing to act as a functional "meta" layer over the design.

## 4. Elevation & Depth
In this design system, hierarchy is achieved through **Tonal Layering** rather than traditional structural lines.

### The Layering Principle
Depth is created by stacking tiers. To lift a card from a background, do not add a border. Instead, place a `surface-container-lowest` card on a `surface-container-low` section. The subtle shift in gray values creates a sophisticated, natural lift.

### Ambient Shadows
Shadows are a last resort. When a floating effect (like a modal or dropdown) is required, the shadow must be "Ambient":
*   **Color:** `on_surface` (#1b1b1b) at 5% opacity.
*   **Blur:** 48px to 64px.
*   **Spread:** -4px to ensure the shadow feels like a soft glow rather than a harsh edge.

### The "Ghost Border" Fallback
If an element requires a container for accessibility (e.g., an input field), use a **Ghost Border**. Apply `outline-variant` (#c6c6c6) at 20% opacity. This provides a functional boundary without cluttering the visual field with high-contrast lines.

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (#000000) with `on_primary` (#e2e2e2) text. 0px border-radius.
*   **Secondary:** `secondary_container` (#d4d4d4) with `on_secondary_container` (#1b1b1b) text.
*   **Tertiary:** No background. Text-only using `primary` (#000000), utilizing `label-md` for a technical feel.

### Input Fields
*   **Container:** `surface-container-low` (#f3f3f3).
*   **Border:** A single bottom-border using `outline` (#777777) at 1px thickness.
*   **States:** On focus, transition the bottom border to `primary` (#000000) and increase thickness to 2px.

### Chips & Badges
*   **Style:** Minimalist boxes using `surface-container-highest` (#e2e2e2). 
*   **Text:** `label-sm` font style. Avoid icons unless they are essential for navigation.

### Cards & Lists
*   **Structure:** Absolutely no divider lines between list items. Use 16px or 24px of vertical white space to separate items.
*   **Cards:** Use background color shifts (`surface-container-lowest`) to define the card area. If multiple cards are used, separate them with 32px of margin to emphasize the "Editorial" grid.

### Custom Component: The Blueprint Marker
Use `primary_fixed` (#5e5e5e) lines of 0.5px thickness that extend slightly beyond the edges of images or containers to mimic architectural crop marks. This reinforces the "Blueprint" aesthetic.

## 6. Do's and Don'ts

### Do:
*   **Embrace the Void:** Use massive amounts of white space. If a section feels crowded, double the padding.
*   **Align to the Grid:** Every element must snap to a strict 8px grid. In a system with no curves, misalignment is glaring.
*   **Use Value for Emphasis:** Use `#000000` only for the most important actions or headings. Use `#5e5e5e` (Secondary) for supporting information.

### Don't:
*   **No Rounded Corners:** Do not use `border-radius` on any element. All boxes, buttons, and inputs must have 90-degree corners.
*   **No 100% Black Borders:** Avoid harsh black outlines. They look "cheap" and "default." Use tonal shifts instead.
*   **No Decorative Icons:** Only use icons if they serve a functional purpose (e.g., a "Close" X). Do not use icons for visual flair.